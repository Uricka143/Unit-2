//
//  MovieGridCell.swift
//  FlixApp
//
//  Created by user187066 on 2/7/21.
//

import UIKit

class MovieGridCell: UICollectionViewCell {
    
    @IBOutlet weak var posterView: UIImageView!
    
}
